const express = require("express");
const http = require("http");
const path = require("path");
const fs = require("fs");
const { Server } = require("socket.io");

const app = express();
const server = http.createServer(app);
const io = new Server(server);
const PORT = process.env.PORT || 3000;
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, "data");
const SCORES_FILE = path.join(DATA_DIR, "scores.json");

fs.mkdirSync(DATA_DIR, { recursive: true });
if (!fs.existsSync(SCORES_FILE)) fs.writeFileSync(SCORES_FILE, "[]", "utf8");

app.use(express.static(path.join(__dirname, "public")));
app.get("/api/leaderboard", (_req, res) => res.json(readScores()));
app.get("/health", (_req, res) => res.json({ ok: true }));

function readScores() {
  try {
    const parsed = JSON.parse(fs.readFileSync(SCORES_FILE, "utf8"));
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}
function saveScore(entry) {
  const scores = readScores();
  scores.push({
    name: String(entry.name || "小蛇玩家").trim().slice(0, 16) || "小蛇玩家",
    score: Math.max(0, Math.min(1000000, Math.floor(Number(entry.score) || 0))),
    date: new Date().toISOString()
  });
  scores.sort((a, b) => b.score - a.score);
  fs.writeFileSync(SCORES_FILE, JSON.stringify(scores.slice(0, 100), null, 2), "utf8");
  return scores.slice(0, 10);
}

const rooms = new Map();
const COLORS = ["#ff6b6b", "#6c8cff", "#ffb84d", "#a56eff", "#31b987", "#f06fb5"];
function roomCode() {
  return Math.random().toString(36).slice(2, 6).toUpperCase();
}
function publicPlayers(room) {
  return [...room.players.values()].map(p => ({ id: p.id, name: p.name, color: p.color, score: p.score, alive: p.alive }));
}
function emitRoom(room) {
  io.to(room.code).emit("room:update", { code: room.code, players: publicPlayers(room), hostId: room.hostId });
}
function startRoomLoop(room) {
  if (room.loop) clearInterval(room.loop);
  room.loop = setInterval(() => {
    if (!rooms.has(room.code) || room.state !== "playing") {
      clearInterval(room.loop); room.loop = null; return;
    }
    const alive = [...room.players.values()].filter(p => p.alive);
    if (!alive.length) {
      room.state = "finished";
      io.to(room.code).emit("room:finished", { code: room.code });
      emitRoom(room);
      clearInterval(room.loop); room.loop = null; return;
    }
    for (const p of alive) {
      p.dir = p.nextDir || p.dir;
      const head = { ...p.body[0] };
      if (p.dir === "up") head.y--;
      if (p.dir === "down") head.y++;
      if (p.dir === "left") head.x--;
      if (p.dir === "right") head.x++;
      const ate = head.x === room.fruit.x && head.y === room.fruit.y;
      const ownBody = ate ? p.body : p.body.slice(0, -1);
      const otherBodies = [...room.players.values()].filter(q => q.id !== p.id && q.alive).flatMap(q => q.body);
      if (head.x < 0 || head.x >= 24 || head.y < 0 || head.y >= 24 ||
          ownBody.some(s => s.x === head.x && s.y === head.y) ||
          otherBodies.some(s => s.x === head.x && s.y === head.y)) {
        p.alive = false;
        continue;
      }
      p.body.unshift(head); p.x = head.x; p.y = head.y;
      if (ate) {
        p.score += 10;
        let fruit;
        do { fruit = { x: Math.floor(Math.random() * 24), y: Math.floor(Math.random() * 24) }; }
        while ([...room.players.values()].some(q => q.alive && q.body.some(s => s.x === fruit.x && s.y === fruit.y)));
        room.fruit = fruit;
      } else p.body.pop();
    }
    io.to(room.code).emit("room:state", {
      code: room.code, fruit: room.fruit,
      players: [...room.players.values()].map(p => ({
        id: p.id, name: p.name, color: p.color, score: p.score, alive: p.alive,
        body: p.body, dir: p.dir
      }))
    });
    emitRoom(room);
  }, 135);
}

io.on("connection", socket => {
  socket.on("room:create", ({ name } = {}, callback = () => {}) => {
    const code = roomCode();
    const room = { code, hostId: socket.id, players: new Map(), state: "waiting" };
    room.players.set(socket.id, {
      id: socket.id, name: String(name || "玩家").slice(0, 16), color: COLORS[0],
      score: 0, alive: true, x: 5, y: 5, dir: "right", body: [{x:5,y:5},{x:4,y:5},{x:3,y:5}], nextDir: "right"
    });
    rooms.set(code, room);
    socket.join(code);
    callback({ ok: true, code, playerId: socket.id });
    emitRoom(room);
  });
  socket.on("room:join", ({ code, name } = {}, callback = () => {}) => {
    code = String(code || "").trim().toUpperCase();
    const room = rooms.get(code);
    if (!room) return callback({ ok: false, error: "没有找到这个房间，请检查房间码。" });
    if (room.players.size >= 6) return callback({ ok: false, error: "房间最多容纳 6 名玩家。" });
    if (room.state === "playing") return callback({ ok: false, error: "游戏已经开始，暂时不能加入。" });
    const index = room.players.size;
    room.players.set(socket.id, {
      id: socket.id, name: String(name || "玩家").slice(0, 16), color: COLORS[index % COLORS.length],
      score: 0, alive: true, x: 5 + index * 3, y: 5 + index * 2, dir: "right",
      body: [{x:5 + index * 3,y:5 + index * 2},{x:4 + index * 3,y:5 + index * 2},{x:3 + index * 3,y:5 + index * 2}], nextDir: "right"
    });
    socket.join(code);
    callback({ ok: true, code, playerId: socket.id });
    emitRoom(room);
  });
  socket.on("room:start", ({ code } = {}) => {
    const room = rooms.get(String(code || "").toUpperCase());
    if (!room || room.hostId !== socket.id) return;
    room.state = "playing";
    room.fruit = { x: Math.floor(Math.random() * 24), y: Math.floor(Math.random() * 24) };
    room.players.forEach((p, index) => {
      p.alive = true; p.score = 0;
      p.x = 4 + index * 3; p.y = 4 + index * 3;
      p.dir = "right"; p.nextDir = "right";
      p.body = [{x:p.x,y:p.y},{x:p.x-1,y:p.y},{x:p.x-2,y:p.y}];
    });
    io.to(room.code).emit("room:started", { code: room.code });
    emitRoom(room);
    startRoomLoop(room);
  });
  socket.on("player:direction", ({ code, dir } = {}) => {
    const room = rooms.get(String(code || "").toUpperCase());
    const p = room && room.players.get(socket.id);
    if (!p || !["up", "down", "left", "right"].includes(dir)) return;
    const opposite = { up: "down", down: "up", left: "right", right: "left" };
    if (opposite[p.dir] !== dir) p.nextDir = dir;
  });
  socket.on("player:score", ({ code, score } = {}) => {
    const room = rooms.get(String(code || "").toUpperCase());
    const p = room && room.players.get(socket.id);
    if (!p) return;
    p.score = Math.max(p.score, Math.floor(Number(score) || 0));
    emitRoom(room);
  });
  socket.on("score:submit", ({ name, score } = {}, callback = () => {}) => {
    const board = saveScore({ name, score });
    callback({ ok: true, leaderboard: board });
    io.emit("leaderboard:update", board);
  });
  socket.on("disconnect", () => {
    for (const [code, room] of rooms) {
      if (!room.players.has(socket.id)) continue;
      room.players.delete(socket.id);
      if (room.players.size === 0) rooms.delete(code);
      else {
        if (room.hostId === socket.id) room.hostId = room.players.keys().next().value;
        emitRoom(room);
      }
    }
  });
});

server.listen(PORT, () => console.log(`Cloud Snake running on port ${PORT}`));
