(() => {
  const canvas = document.getElementById("game");
  const ctx = canvas.getContext("2d");
  const scoreEl = document.getElementById("score");
  const bestEl = document.getElementById("best");
  const levelEl = document.getElementById("level");
  const overlay = document.getElementById("overlay");
  const overlayTitle = document.getElementById("overlayTitle");
  const overlayText = document.getElementById("overlayText");
  const startBtn = document.getElementById("startBtn");
  const toastEl = document.getElementById("toast");
  const socket = typeof io === "function" ? io() : null;
  const CELLS = 24, CELL = canvas.width / CELLS;
  let snake, fruit, direction, nextDirection, score = 0, best = Number(localStorage.getItem("cloudSnakeBest") || 0);
  let running = false, paused = false, timer = null, soundOn = true, lastSubmitted = false;
  let roomCode = "", playerId = "", isHost = false, roomStarted = false, roomSnapshot = null;
  bestEl.textContent = best;

  function toast(msg) { toastEl.textContent = msg; toastEl.classList.add("show"); clearTimeout(toastEl._t); toastEl._t = setTimeout(() => toastEl.classList.remove("show"), 2500); }
  function beep(freq = 520, duration = .07) {
    if (!soundOn) return;
    try { const Audio = window.AudioContext || window.webkitAudioContext; const a = new Audio(); const o = a.createOscillator(); const g = a.createGain(); o.connect(g); g.connect(a.destination); o.frequency.value = freq; g.gain.value = .035; o.start(); o.stop(a.currentTime + duration); } catch {}
  }
  function randFruit() {
    let p;
    do { p = { x: Math.floor(Math.random() * CELLS), y: Math.floor(Math.random() * CELLS) }; }
    while (snake && snake.some(s => s.x === p.x && s.y === p.y));
    return p;
  }
  function reset() {
    snake = [{x:11,y:12},{x:10,y:12},{x:9,y:12}]; direction = "right"; nextDirection = "right";
    score = 0; fruit = randFruit(); running = false; paused = false; lastSubmitted = false;
    scoreEl.textContent = "0"; levelEl.textContent = "1"; draw();
  }
  function roundedRect(x,y,w,h,r) { ctx.beginPath(); ctx.roundRect(x,y,w,h,r); ctx.fill(); }
  function draw() {
    if (roomStarted && roomSnapshot) { drawRoom(); return; }
    ctx.clearRect(0,0,canvas.width,canvas.height);
    ctx.fillStyle = "#e8f8ec"; ctx.fillRect(0,0,canvas.width,canvas.height);
    // pastel picnic blanket grid
    for(let y=0;y<CELLS;y++) for(let x=0;x<CELLS;x++) {
      if ((x+y)%2===0) { ctx.fillStyle = "#e2f4e6"; ctx.fillRect(x*CELL,y*CELL,CELL,CELL); }
      ctx.fillStyle = "#d4ecd9"; ctx.globalAlpha = .4; ctx.beginPath(); ctx.arc(x*CELL+CELL/2,y*CELL+CELL/2,1.3,0,Math.PI*2); ctx.fill(); ctx.globalAlpha = 1;
    }
    // fruit with leaf
    const fx=(fruit.x+.5)*CELL, fy=(fruit.y+.52)*CELL;
    ctx.save(); ctx.translate(fx,fy); ctx.fillStyle="#ff6f87"; ctx.beginPath(); ctx.arc(0,2,CELL*.34,0,Math.PI*2); ctx.fill();
    ctx.fillStyle="#ffb0bd"; ctx.beginPath(); ctx.arc(-3,-2,3,0,Math.PI*2); ctx.fill();
    ctx.fillStyle="#42b883"; ctx.beginPath(); ctx.ellipse(5,-CELL*.3,5,2.5,-.5,0,Math.PI*2); ctx.fill(); ctx.restore();
    // snake body
    snake.forEach((s,i)=>{
      const x=s.x*CELL,y=s.y*CELL, pad=i===0?2.2:3.5;
      ctx.fillStyle = i===0 ? "#48c89a" : `hsl(${151 - Math.min(i*1.3,25)}, 53%, ${66-Math.min(i*.3,9)}%)`;
      roundedRect(x+pad,y+pad,CELL-pad*2,CELL-pad*2,i===0?8:6);
      if(i===0) {
        ctx.fillStyle="#fff"; let ex=x+CELL/2,ey=y+CELL/2;
        if(direction==="right"){ex=x+CELL*.68;ey=y+CELL*.35;} if(direction==="left"){ex=x+CELL*.32;ey=y+CELL*.35;}
        if(direction==="up"){ex=x+CELL*.65;ey=y+CELL*.32;} if(direction==="down"){ex=x+CELL*.65;ey=y+CELL*.68;}
        ctx.beginPath();ctx.arc(ex,ey,3.8,0,Math.PI*2);ctx.fill();
        ctx.fillStyle="#37475a";ctx.beginPath();ctx.arc(ex+(direction==="left"?-1:direction==="right"?1:0),ey+(direction==="up"?-1:direction==="down"?1:0),1.8,0,Math.PI*2);ctx.fill();
        ctx.fillStyle="#f77b9e";
        if(direction==="right"||direction==="left"){ctx.beginPath();ctx.ellipse(x+CELL/2,y+CELL*.68,4,2,0,0,Math.PI*2);ctx.fill();}
      }
    });
  }
  function drawRoom() {
    ctx.clearRect(0,0,canvas.width,canvas.height);
    ctx.fillStyle="#e8f8ec";ctx.fillRect(0,0,canvas.width,canvas.height);
    for(let y=0;y<CELLS;y++)for(let x=0;x<CELLS;x++){if((x+y)%2===0){ctx.fillStyle="#e2f4e6";ctx.fillRect(x*CELL,y*CELL,CELL,CELL);}}
    const f=roomSnapshot.fruit;
    if(f){ctx.fillStyle="#ff6f87";ctx.beginPath();ctx.arc((f.x+.5)*CELL,(f.y+.52)*CELL,CELL*.34,0,Math.PI*2);ctx.fill();ctx.fillStyle="#42b883";ctx.beginPath();ctx.ellipse((f.x+.65)*CELL,(f.y+.25)*CELL,5,2.5,-.5,0,Math.PI*2);ctx.fill();}
    (roomSnapshot.players||[]).forEach(p=>{
      (p.body||[]).forEach((s,i)=>{
        ctx.fillStyle=p.alive?p.color:"#b8b8b8";ctx.globalAlpha=p.alive?1:.55;
        ctx.beginPath();ctx.roundRect(s.x*CELL+3,s.y*CELL+3,CELL-6,CELL-6,i===0?8:5);ctx.fill();
        if(i===0&&p.alive){ctx.fillStyle="#fff";ctx.beginPath();ctx.arc((s.x+.68)*CELL,(s.y+.35)*CELL,3.2,0,Math.PI*2);ctx.fill();}
      });
    });
    ctx.globalAlpha=1;
  }
  function speed() { return Math.max(72, 145 - Math.floor(score / 30) * 8); }
  function tick() {
    if (!running || paused) return;
    direction = nextDirection;
    const head = {...snake[0]};
    if(direction==="right")head.x++; if(direction==="left")head.x--; if(direction==="up")head.y--; if(direction==="down")head.y++;
    if(head.x<0||head.x>=CELLS||head.y<0||head.y>=CELLS||snake.some((s,i)=>i<snake.length-1&&s.x===head.x&&s.y===head.y)){ endGame(); return; }
    snake.unshift(head);
    if(head.x===fruit.x&&head.y===fruit.y){ score+=10; scoreEl.textContent=score; levelEl.textContent=String(1+Math.floor(score/50)); fruit=randFruit(); beep(720,.08); if(score>best){best=score;bestEl.textContent=best;localStorage.setItem("cloudSnakeBest",best);} if(socket&&roomCode)socket.emit("player:score",{code:roomCode,score}); }
    else snake.pop();
    draw(); clearTimeout(timer); timer=setTimeout(tick,speed());
  }
  function start() {
    if (!snake || !snake.length) reset();
    overlay.classList.add("hidden"); running=true;paused=false;clearTimeout(timer);tick();
  }
  function endGame() {
    running=false;paused=false;clearTimeout(timer);beep(180,.18);
    overlayTitle.textContent="哎呀，撞到啦！";overlayText.textContent=`本局获得 ${score} 分，休息一下再来挑战吧！`;startBtn.innerHTML='再玩一次 <span>↻</span>';overlay.classList.remove("hidden");
    if(score>0) toast("游戏结束！可以把分数上传到云端排行榜。");
  }
  function setDir(d) {
    const opposite={up:"down",down:"up",left:"right",right:"left"};
    if(opposite[direction]===d)return;
    nextDirection=d;
    if(socket&&roomCode)socket.emit("player:direction",{code:roomCode,dir:d});
  }
  function togglePause() {
    if(!running)return;
    paused=!paused;
    if(paused){clearTimeout(timer);overlayTitle.textContent="暂停一下 ☁️";overlayText.textContent="准备好了就继续吧！";startBtn.innerHTML='继续游戏 <span>▶</span>';overlay.classList.remove("hidden");}
    else {overlay.classList.add("hidden");tick();}
  }
  startBtn.addEventListener("click",()=>{if(running&&paused){togglePause();return;}reset();start();});
  document.addEventListener("keydown",e=>{
    const k=e.key.toLowerCase(), map={arrowup:"up",w:"up",arrowdown:"down",s:"down",arrowleft:"left",a:"left",arrowright:"right",d:"right"};
    if(map[k]){e.preventDefault();setDir(map[k]);if(!running&&!paused){}}
    if(k===" "){e.preventDefault();togglePause();}
  });
  document.querySelectorAll("[data-dir]").forEach(b=>{
    b.addEventListener("pointerdown",e=>{e.preventDefault();setDir(b.dataset.dir);});
  });
  let touchX=0,touchY=0;
  canvas.addEventListener("touchstart",e=>{const t=e.changedTouches[0];touchX=t.clientX;touchY=t.clientY;},{passive:true});
  canvas.addEventListener("touchend",e=>{const t=e.changedTouches[0],dx=t.clientX-touchX,dy=t.clientY-touchY;if(Math.max(Math.abs(dx),Math.abs(dy))<18)return;setDir(Math.abs(dx)>Math.abs(dy)?(dx>0?"right":"left"):(dy>0?"down":"up"));},{passive:true});
  document.getElementById("soundBtn").addEventListener("click",()=>{soundOn=!soundOn;document.getElementById("soundBtn").textContent=soundOn?"🔊":"🔇";toast(soundOn?"音效已开启":"音效已关闭");});
  async function loadBoard() {
    const el=document.getElementById("leaderboard");
    try {
      const res=await fetch("/api/leaderboard"); const rows=await res.json();
      if(!rows.length){el.innerHTML='<div class="empty">还没有冠军记录，快来拿下第一名！ 🏅</div>';return;}
      el.innerHTML=rows.slice(0,10).map((r,i)=>`<div class="board-row"><span class="rank">${["🥇","🥈","🥉"][i]||("0"+(i+1)).slice(-2)}</span><span class="board-name"></span><strong class="board-score">${Number(r.score)||0}</strong></div>`).join("");
      [...el.querySelectorAll(".board-name")].forEach((n,i)=>n.textContent=rows[i].name||"小蛇玩家");
    } catch {el.innerHTML='<div class="empty">排行榜需要连接服务器后才能使用。</div>';}
  }
  document.getElementById("refreshBoard").addEventListener("click",loadBoard);
  document.getElementById("submitScore").addEventListener("click",()=>{
    if(score<=0){toast("先玩一局，再来上传分数吧！");return;}
    const name=document.getElementById("playerName").value.trim()||"小蛇玩家";
    if(!socket){toast("请先部署到云端服务器后再提交。");return;}
    socket.emit("score:submit",{name,score},result=>{if(result&&result.ok){toast("分数上传成功！已进入云端排行榜。");loadBoard();}else toast("上传失败，请稍后再试。");});
  });
  if(socket){
    socket.on("leaderboard:update",loadBoard);
    socket.on("connect",loadBoard);
    socket.on("disconnect",()=>{if(roomCode)document.getElementById("roomStatus").textContent="连接中断，正在尝试重新连接…";});
    socket.on("room:update",data=>{
      if(data.code!==roomCode)return;
      isHost=data.hostId===socket.id;
      document.getElementById("roomStatus").textContent=`房间码：${data.code} · ${data.players.length}/6 人`;
      document.getElementById("roomPlayers").innerHTML=data.players.map(p=>`<span class="player-chip" style="border-color:${p.color}55">${p.id===data.hostId?"👑 ":"🐍 "}${escapeHtml(p.name)}${p.id===socket.id?"（你）":""}</span>`).join("");
      document.getElementById("startRoom").classList.toggle("hidden",!isHost||data.players.length<1||roomStarted);
    });
    socket.on("room:started",data=>{if(data.code===roomCode){roomStarted=true;running=false;clearTimeout(timer);document.getElementById("roomStatus").textContent="联机比赛开始！用方向键控制你的蛇，撞到蛇身或墙壁就会淘汰。";document.getElementById("startRoom").classList.add("hidden");toast("联机比赛开始啦！");}});
    socket.on("room:state",data=>{if(data.code===roomCode){roomSnapshot=data;const me=(data.players||[]).find(p=>p.id===socket.id);if(me){score=me.score;scoreEl.textContent=score;levelEl.textContent="联机";if(!me.alive){document.getElementById("roomStatus").textContent="你被淘汰啦！可以观战或等待房主重新开始。";}}draw();}});
    socket.on("room:finished",data=>{if(data.code===roomCode){document.getElementById("roomStatus").textContent="本轮联机结束，房主可以重新开始。";roomStarted=false;draw();}});
  }
  function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
  document.getElementById("createRoom").addEventListener("click",()=>{
    if(!socket)return toast("需要部署服务器才能创建联机房。");
    socket.emit("room:create",{name:document.getElementById("roomName").value.trim()||"玩家"},res=>{
      if(!res.ok)return toast("创建失败，请稍后重试。");
      roomCode=res.code;playerId=res.playerId;roomStarted=false;roomSnapshot=null;document.getElementById("roomCode").value=roomCode;document.getElementById("startRoom").classList.remove("hidden");toast("房间创建成功！把房间码发给朋友吧。");
    });
  });
  document.getElementById("joinRoom").addEventListener("click",()=>{
    if(!socket)return toast("需要部署服务器才能加入联机房。");
    const code=document.getElementById("roomCode").value.trim().toUpperCase();
    socket.emit("room:join",{code,name:document.getElementById("roomName").value.trim()||"玩家"},res=>{
      if(!res.ok)return toast(res.error||"加入失败");
      roomCode=res.code;playerId=res.playerId;roomStarted=false;roomSnapshot=null;toast("加入房间成功！");
    });
  });
  document.getElementById("startRoom").addEventListener("click",()=>{if(socket&&roomCode)socket.emit("room:start",{code:roomCode});});
  reset();loadBoard();
})();
